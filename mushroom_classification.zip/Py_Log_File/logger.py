
from datetime import datetime

class App_logger:
    def __init__(self):
        pass
    def log(self,file,message):
        self.date=datetime.now().date()
        self.time=datetime.now().strftime("%H:%M:%S")
        file.write( str(self.date)+ "-" + str(self.time) + "/" + "\t\t" + message +"\n")
        
#obj=App_logger()
#file=open("test_log_file.txt","a+")
#obj.log(file,"this is test message")