import shutil 
import os
from datetime import datetime
import re
import pandas as pd
from Py_Log_File.logger import App_logger

#path=input("Enter a Path of directory :\t")
#path="Prediction_Batch_files/"
import json

class Pred_Raw_Data_validation:
    
    def __init__(self,path):
        self.path=path
        self.schema="schema_prediction.json"
        self.logger=App_logger()
        
    def valuesFromSchema(self):
        try:
            f=open(self.schema,"r")
            dic = json.load(f)
            f.close()
            pattern = dic['SampleFileName']
            LengthOfDateStampInFile = dic['LengthOfDateStampInFile']
            LengthOfTimeStampInFile = dic['LengthOfTimeStampInFile']
            column_names = dic['ColName']
            NumberofColumns = dic['NumberofColumns']
            log_file=open("Prediction_Logs/CreateGoodBad_dir_log.txt","a+")
            self.logger.log(log_file,"Schema file reading successfully done")
            log_file.close()
            #return pattern ,LengthOfDateStampInFile ,LengthOfTimeStampInFile, column_names ,NumberofColumns
        except Exception as e:
            #print("Error occure at schema reading")
            log_file=open("Prediction_Logs/CreateGoodBad_dir_log.txt","a+")
            self.logger.log(log_file,"Schema file reading Error Occured")
            log_file.close()
        return pattern ,LengthOfDateStampInFile ,LengthOfTimeStampInFile, column_names ,NumberofColumns
         
    
    def manualRegexCreation(self):
        print("Manual regex")
        regex = "['mushroom']+['\_'']+[\d_]+[\d]+\.csv"  # mushroom_08012020_120000.csv
        return regex
    
    def createDirectoryForGoodBadRawData(self):
        try:
            path = os.path.join("Prediction_Raw_files_validated/", "Good_Raw/")
            if not os.path.isdir(path):
                os.makedirs(path)
            path=os.path.join("Prediction_Raw_files_validated/","Bad_Raw/")
            if not os.path.isdir(path):
                os.makedirs(path)
            log_file=open("Prediction_Logs/CreateGoodBad_dir_log.txt","a+")
            #print("Successfully Created GOOD_BAD data folder")
            self.logger.log(log_file,"Successfully Created GOOD_BAD data folder")        
        except Exception as e:
            #print("Error occured While creating file")
            log_file=open("Prediction_Logs/CreateGoodBad_dir_log.txt","a+")
            #print("Error while Creating GOOD_BAD data folder")
            self.logger.log(log_file,"Error while Creating GOOD_BAD data folder" +str(e))
            
    def deleteExistingGoodDataTrainingFolder(self):
        try:
            path="Prediction_Raw_files_validated/Good_Raw/"
            shutil.rmtree(path)
            log_file=open("Prediction_Logs/DeleteGood_BAD_dir_log.txt","a+")
            #print(" Deleteing GOOD data folder successfully done")
            self.logger.log(log_file,"Deleteing GOOD data folder successfully don")
        except Exception as e:
            log_file=open("Prediction_Logs/DeleteGood_BAD_dir_log.txt","a+")
            #print("Error while Deleteing GOOD data folder")
            self.logger.log(log_file,"Error while Deleteing GOOD data folder" +str(e))
            
    def deleteExistingBadDataTrainingFolder(self):
        try:
            path="Prediction_Raw_files_validated/Bad_Raw/"
            shutil.rmtree(path)
            log_file=open("Prediction_Logs/DeleteGood_BAD_dir_log.txt","a+")
            #print(" Deleteing BAD data folder successfully done")
            self.logger.log(log_file,"Deleteing BAD data folder successfully don")
        except  Exception as e:
            log_file=open("Prediction_Logs/DeleteGood_BAD_dir_log.txt","a+")
            #print("Error while Deleteing BAD data folder")
            self.logger.log(log_file,"Error while Deleteing BAD data folder" +str(e)) 
            
    def moveBadFilesToArchiveBad(self):
        try:
            source="Prediction_Raw_files_validated/Bad_Raw/"
            dest="PredictionArchiveBadData/"
            if not os.path.isdir(dest):
                os.makedirs(dest)
            for file in os.listdir(source):
                shutil.move(source+file, dest)
            log_file=open("Prediction_Logs/DeleteGood_BAD_dir_log.txt","a+")
            #print("Moving to Archived Data successfull ")
            self.logger.log(log_file,"Moving to Archived Data successfull")    
        except Exception as e:
            log_file=open("Prediction_Logs/DeleteGood_BAD_dir_log.txt","a+")
            #print(" Moving data to archive successfully done")
            self.logger.log(log_file,"Error Moving data to archive data" +str(e))
            
    def validationFileNameRaw(self,regex,LengthOfDateStampInFile,LengthOfTimeStampInFile):
        self.deleteExistingGoodDataTrainingFolder()
        self.deleteExistingBadDataTrainingFolder()
        log_file = open("Prediction_Logs/nameValidationLog.txt", 'a+')
        try:
            self.createDirectoryForGoodBadRawData()
            for filename in os.listdir(self.path):
                #print(filename)
                if re.match(regex,filename):
                    splitDot=re.split(".csv",filename)
                    splitDot=re.split("_",splitDot[0])
                    if len(splitDot[1]) == LengthOfDateStampInFile :
                        if len(splitDot[2]) == LengthOfTimeStampInFile :
                            shutil.copyfile("Prediction_Batch_files/"+filename, "Prediction_Raw_files_validated/Good_Raw/"+filename) 
                            self.logger.log(log_file,"Valid File name!! File moved to GoodRaw Folder ")
                        else:
                            shutil.copyfile("Prediction_Batch_files/" + filename, "Prediction_Raw_files_validated/Bad_Raw/"+filename)
                            self.logger.log(log_file,"Invalid File name!! File moved to GoodRaw Folder ")
                    else:
                        shutil.copyfile("Prediction_Batch_files/" + filename, "Prediction_Raw_files_validated/Bad_Raw/"+filename)
                        self.logger.log(log_file,"Invalid File name!! File moved to GoodRaw Folder ")
                else:
                    shutil.copyfile("Prediction_Batch_files/" + filename, "Prediction_Raw_files_validated/Bad_Raw/"+filename)
                    self.logger.log(log_file,"Invalid File name!! File moved to GoodRaw Folder ")
            log_file.close()                
        except Exception as e:
            #print("Error in Validaation of filename")
            self.logger.log(log_file,"Error in Validaation of filename"+str(e))
            log_file.close()
            
    def validateColumnLength(self,NumberofColumns):
        log_file = open("Prediction_Logs/columnValidationLog.txt", 'a+')
        try:
            for file in os.listdir("Prediction_Raw_files_validated/Good_Raw/"):
                csv=pd.read_csv("Prediction_Raw_files_validated/Good_Raw/"+file)
                if csv.shape[1]==NumberofColumns:
                    pass
                else:
                    shutil.move("Prediction_Raw_files_validated/Good_Raw/"+file,"Prediction_Raw_files_validated/Bad_Raw")
                #print("Number of columns validation done successfully.")
                self.logger.log(log_file,"Number of columns validation done successfully.")    
        except Exception as e:
            self.logger.log(log_file,"Error in Number of column validation." +str(e))
            #print("Error in Number of column validation.")
            log_file.close()
            
    def validateMissingValuesInWholeColumn(self):
        log_file = open("Prediction_Logs/validateMissingValuesInWholeColumn.txt", 'a+')
        try:
            #iterate over each file
            for file in os.listdir("Prediction_Raw_files_validated/Good_Raw/"):
                #iterate over each file column
                csv=pd.read_csv("Prediction_Raw_files_validated/Good_Raw/"+file)
                for columns in csv:
                    if ( len(csv[columns]) - csv[columns].count() == len(csv[columns]) ) :
                        shutil.move("Prediction_Raw_files_validated/Good_Raw/"+file,"Prediction_Raw_files_validated/Bad_Raw")
                        
                        self.logger.log(log_file,"validateMissingValuesInWholeColumn moved file to bad_raw folder")
                    else:
                        pass
            #print("validateMissingValuesInWholeColumn Done successfully")        
            self.logger.log(log_file,"validateMissingValuesInWholeColumn Done successfully")        
            log_file.close()            
        except Exception as e:
            #print("Error while validateMissingValuesInWholeColumn ")
            self.logger.log(log_file,"validateMissingValuesInWholeColumn occured Error" +str(e))        
            log_file.close()
    
    def deletePredictionFile(self):
        try:
            log_file = open("Prediction_Logs/Delete_Existing_Prediction_Folder.txt", 'a+')
            if os.path.exists('Prediction_Output_File/Predictions.csv'):
                os.remove('Prediction_Output_File/Predictions.csv')
            self.logger.log(log_file,"Successfully delete Exiisted PredictionFile")
        except Exception as e:
            self.logger.log(log_file,"Error in delete Exiisted PredictionFile" +str(e))        
            
    
                           
#obj=Raw_Data_validation(path)
#obj.createDirectoryForGoodBadRawData()
     #obj.deleteExistingGoodDataTrainingFolder()
     #obj.deleteExistingBadDataTrainingFolder()
     #obj.moveBadFilesToArchiveBad()
#regex=obj.manualRegexCreation()
#pattern ,LengthOfDateStampInFile ,LengthOfTimeStampInFile, column_names ,NumberofColumns=obj.valuesFromSchema()
#obj.validationFileNameRaw(regex,LengthOfDateStampInFile ,LengthOfTimeStampInFile )
#obj.validateColumnLength(NumberofColumns)
#obj.validateMissingValuesInWholeColumn()
#obj.deletePredictionFile()