import pickle
import os
import shutil
from Py_Log_File.logger import App_logger

class File_Operation:
    
    def __init__(self):
        self.logger=App_logger()
        self.model_directory='models/'
        
    def save_model(self,model,filename):
        print("In saved model")
        log_file=open("Training_Logs/ModelTrainingLog.txt", 'a+')
        self.logger.log(log_file,"Entered to save model process")
        try:
            path = os.path.join(self.model_directory,filename)
            if not os.path.isdir(path):
                os.makedirs(path)
            else:
                shutil.rmtree(self.model_directory)
                os.makedirs(path) 
            with open(path +'/' + filename+'.sav','wb') as f:
                pickle.dump(model, f)
            self.logger.log(log_file,"Saved model to local system")    
                
        except Exception as e:
            self.logger.log(log_file,"Error in Saving model to local system" +str(e))
            raise Exception()
            
    def load_model(self,filename):
        log_file=open("Training_Logs/ModelTrainingLog.txt", 'a+')
        self.logger.log(log_file, 'Entered the load_model method of the File_Operation class')
        try:
            with open(self.model_directory + filename + '/' + filename + '.sav', 'rb') as f:
                self.logger.log(log_file,'Model File ' + filename + ' loaded. Exited the load_model method of the Model_Finder class')
                return pickle.load(f)
        except Exception as e:
            self.logger.log(log_file,'Exception occured in load_model ' + str(e))
            self.logger.log(log_file,'Model File ' + filename + ' could not be saved. Exited the load_model method of the Model_Finder class')
            raise Exception()
     
    def find_correct_model_file(self,cluster_number):
        log_file=open("Training_Logs/ModelTrainingLog.txt", 'a+')
        self.logger.log(log_file, 'Entered the find_correct_model_file method of the File_Operation class')
        try:
            self.cluster_number= cluster_number
            self.folder_name=self.model_directory
            self.list_of_model_files = []
            self.list_of_files = os.listdir(self.folder_name)
            for self.file in self.list_of_files:
                try:
                    if (self.file.index(str( self.cluster_number))!=-1):
                        self.model_name=self.file
                except:
                    continue
            self.model_name=self.model_name.split('.')[0]
            self.logger.log(log_file,'Exited the find_correct_model_file method of the Model_Finder class.')
            return self.model_name
        
        except Exception as e:
            self.logger.log(log_file,'Exception occured in find_correct_model_file method   ' + str(e))
            self.logger.log(log_file,'Exited the find_correct_model_file method of the Model_Finder class with Failure')
            raise Exception()
    