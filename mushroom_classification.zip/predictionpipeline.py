from Py_Log_File.logger import App_logger
from Prediction_Data_Validation.pred_data_val import Pred_Raw_Data_validation
from Prediction_Data_Tranformation.pred_data_transform import DataTranform
from Prdiction_DB_Operation.pred_db_operation import dBOperation
from Prediction_Load_Data.pred_load_data import Data_Getter
from Predictio_Data_Preprocessing.pred_data_preprocess import Preprocessor
from Prediction_File.prediction import Prediction


class Make_Prediction:
    def __init__(self,path):
        self.logger=App_logger()
        self.Pred_Raw_Data_validation=Pred_Raw_Data_validation(path)
        self.DataTranform=DataTranform()
        self.dBOperation=dBOperation()
        self.Data_Getter=Data_Getter()
        self.Preprocessor=Preprocessor()
        self.Prediction=Prediction()

    def Predict_Now(self):
        log_file = open("Prediction_Logs/General.txt", 'a+')
        try:
            self.logger.log(log_file," Started Prediction...........")
            self.logger.log(log_file,"*********** Start of Data Validation ***************")
            self.Pred_Raw_Data_validation.createDirectoryForGoodBadRawData()
            self.logger.log(log_file,"Successfully created Good and Bas Data directory Folder..")
            regex=self.Pred_Raw_Data_validation.manualRegexCreation()
            self.logger.log(log_file,"Successfully Get a regex pattern .....")
            pattern ,LengthOfDateStampInFile ,LengthOfTimeStampInFile, column_names ,NumberofColumns=self.Pred_Raw_Data_validation.valuesFromSchema()
            self.logger.log(log_file,"Successfully Read a schema values")
            self.Pred_Raw_Data_validation.validationFileNameRaw(regex,LengthOfDateStampInFile ,LengthOfTimeStampInFile )
            self.logger.log(log_file,"Successfully Done Name validation")
            self.Pred_Raw_Data_validation.validateColumnLength(NumberofColumns)
            self.logger.log(log_file,"Successfully done ColumnLength Validation")
            self.Pred_Raw_Data_validation.validateMissingValuesInWholeColumn()
            self.logger.log(log_file,"Successfully checked if Missing values are in whole column")
            self.Pred_Raw_Data_validation.deletePredictionFile()
            self.logger.log(log_file,"Successfully Deleted The previous Prediction file if availabel ")
            self.logger.log(log_file,"End of Prediction Data validation..")

            self.logger.log(log_file,"")
 
            self.logger.log(log_file,"*********** Start of Data Transformation ***************")
            self.DataTranform.addQuotesToStringValuesInColumn()
            self.logger.log(log_file,"End Of data Tranformation")
 
            self.logger.log(log_file,"")
 
            self.logger.log(log_file,"*********** Start of DataBase Operation ***************") 
            self.dBOperation.dataBaseConnection("Prediction")
            self.logger.log(log_file,"Successfully Done database connection ")
            self.dBOperation.createTableDb("Prediction",column_names)
            self.logger.log(log_file,"Successfully Created Database Table")
            self.dBOperation.insertIntoTableGoodData("Prediction") 
            self.logger.log(log_file,"Successfully Inserted Good Data to DataBase Table")
            self.dBOperation.selectingDatafromtableintocsv("Prediction")
            self.logger.log(log_file,"Successfully Saved all data csv file locally")
            self.logger.log(log_file,"End Of DataBase Operation ....")
            
            self.logger.log(log_file,"")

            self.logger.log(log_file,"*********** Start of Data Reading ***************") 
            data=self.Data_Getter.get_data()
            self.logger.log(log_file,"End of Data Reading..")

            self.logger.log(log_file,"")

            self.logger.log(log_file,"*********** Start of Prediction Data Preprocessing ***************")
            self.Preprocessor.dropUnnecessaryColumns(data,['veiltype'])
            self.logger.log(log_file,"Successfully Dropped unnecessary columns")
            self.Preprocessor.replaceInvalidValuesWithNull(data)
            self.logger.log(log_file,"Successfully Replaced '?' with nan " )
            is_null_present,cols_with_missing_values=self.Preprocessor.is_null_present(data)
            self.logger.log(log_file,"Successfully Checked for nul values present .."+str(is_null_present)+str(cols_with_missing_values))
            if (is_null_present)==True:
                data=self.Preprocessor.impute_missing_values(data,cols_with_missing_values)
                self.logger.log(log_file,"Successfully Imputed missing values")
            data=self.Preprocessor.encodeCategoricalValues(data)    
            self.logger.log(log_file,"Successfully Encoded the categorical values")
            self.logger.log(log_file,"End of Data Preprocessing..")
            self.logger.log(log_file,"*********** Start of Prediction Data Prediction ***************")
            self.Prediction.Prediction_model(data)
            self.logger.log(log_file,"End of Prediction..")


        except Exception as e:
            self.logger.log(log_file,"Error in Prediction Pipeline "+str(e))
