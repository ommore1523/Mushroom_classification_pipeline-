from matplotlib import pyplot as plt
import seaborn as sns
from Train_File_Operation.train_file_operation import File_Operation
import os
import pandas as pd
from Py_Log_File.logger import App_logger

class Prediction:
    def __init__(self):
        self.logger=App_logger()
        self.File_Operation=File_Operation()
    
    def Prediction_model(self,data):
        log_file=open("Prediction_Logs/ModelPredictionLog.txt", 'a+')
        try:
            print("In prediction Model..")
            Kmeans=self.File_Operation.load_model('KMeans')
            print("loaded kmeans")
            clusters=Kmeans.predict(data)
            print("Predicted cluseters")
            data['clusters']=clusters
            clusters=data['clusters'].unique()
            print(clusters)
        
            path="Prediction_Output_File/"
            if not os.path.isdir(path):
                os.makedirs(path)
            
            result=[]
            
            for i in clusters:
                print(i)
                cluster_data= data[data['clusters']==i]
                cluster_data = cluster_data.drop(['clusters'],axis=1)
                model_name = self.File_Operation.find_correct_model_file(i)
                print("model_name",model_name)
                model=self.File_Operation.load_model(model_name)
                pred=model.predict(cluster_data)
                for val in pred:
                    result.append(val)
            self.logger.log(log_file, 'Model prediction done successfully...')        
            print(result)    
            result = pd.DataFrame(result,columns=['Predictions'])
            result.to_csv("Prediction_Output_File/Predictions.csv",header=True)
            self.logger.log(log_file, 'Model prediction csv file saved locally')   
            ax = sns.countplot(x=df1["Predictions"], data=df1)
            fig = ax.get_figure()
            fig.savefig('Prediction_Output_File/pred.png')
            self.logger.log(log_file, 'Model prediction prediction class graph save locally')
            self.logger.log(log_file, 'Model prediction completed....')      


        except Exception as e:
            self.logger.log(log_file, 'Error in Prdiction file ....')   

        
#obj=prediction()
#obj.Prediction_model()        