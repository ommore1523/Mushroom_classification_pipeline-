import os

from  flask       import request
from  train_model import Train_model
from  flask       import Flask ,render_template,redirect
from  predictionpipeline            import Make_Prediction
from  training_validation_insertion import train_validation_class






app = Flask(__name__)


@app.route('/')
def hello_world():
    return render_template ("home.html")


#Training route
@app.route('/train' ,methods=['POST'])
def train():
    if request.method == 'POST':
        path= request.form['path']
        Log_path="Training_Logs/"
        if not os.path.isdir(Log_path):
            os.makedirs(Log_path)
            
        train_validation=train_validation_class(path)
        train_validation.train_validation()

        train_model_now=Train_model()
        train_model_now.train_model()
        print(path)
        return redirect('/')
    else:
        return redirect('/')    



#Prediction route
@app.route('/predict' ,methods=['POST'])
def predict():
    if request.method == 'POST':
        path= request.form['path']
        Log_path="Prediction_Logs/"
        if not os.path.isdir(Log_path):
            os.makedirs(Log_path)
        Pred=Make_Prediction(path)
        Pred.Predict_Now()
        print(path)
        return redirect('/')
    else:
        return redirect('/')            



if __name__ == '__main__':
    app.run()