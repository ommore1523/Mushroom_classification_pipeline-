import pandas as pd
from Py_Log_File.logger import App_logger


class Data_Getter:
    def __init__(self):
        self.logger=App_logger()
        self.train_file='Prediction_FileFromDB/PredictionFile.csv'
        
    def get_data(self):
        log_file=open("Prediction_Logs/ModelPredictionLog.txt", 'a+')
        self.logger.log(log_file,"Reading the train csv file started..")
        try:
            self.data=pd.read_csv(self.train_file)
            self.logger.log(log_file,"Successfully Read the train csv.")
            log_file.close()
            return self.data
        except Exception as e:
            self.logger.log(log_file,"Error occeured while reading train csv file"+str(e))
            log_file.close()
            raise Exception()
#obj=Data_Getter()
#data=obj.get_data()