import sqlite3
import csv
from Py_Log_File.logger import App_logger
import os

class dBOperation:
    def __init__(self):
        self.path="Training_Database/"
        self.badFilePath="Training_Raw_files_validated/Bad_Raw"
        self.goodFilePath="Training_Raw_files_validated/Good_Raw"
        self.logger = App_logger()
        
    def dataBaseConnection(self,DatabaseName):
        conn=None
        log_file = open("Training_Logs/DataBaseConnectionLog.txt", 'a+')
        try:
            path="Training_Database/"
            if not os.path.isdir(path):
                os.makedirs(path)
            conn = sqlite3.connect(self.path+DatabaseName+'.db')
            self.logger.log(log_file, "Database connection Done successfully")
            print("Database connection Done successfully")
            log_file.close()
        except Exception as e:
            print("Error in DB connection " +str(e))
            self.logger.log(log_file, "Error in DB connection")
            log_file.close()
        return conn
    def createTableDb(self,DatabaseName,column_names):
        try:
            conn=self.dataBaseConnection(DatabaseName)
            log_file = open("Training_Logs/DataBaseConnectionLog.txt", 'a+')
            c=conn.cursor()
            c.execute("SELECT count(name)  FROM sqlite_master WHERE type = 'table' AND name = 'Good_Raw_Data'")
            if c.fetchone()[0] ==1:
                conn.close()
                print("Table already exist")
                #print("Table created successfully")
                self.logger.log(log_file, "Table created in DB Done successfully")
                log_file.close()
            else:
                for key in column_names.keys():
                    type = column_names[key]
                    
                    try:
                        conn.execute('ALTER TABLE Good_Raw_Data ADD COLUMN "{column_name}" {dataType}'.format(column_name=key,dataType=type))
                    except:
                        conn.execute('CREATE TABLE  Good_Raw_Data ({column_name} {dataType})'.format(column_name=key, dataType=type))
                conn.close()

                self.logger.log(log_file, "Tables created successfully!!")
                print("Table created successfully")
                log_file.close()
        except Exception as e:
            conn.close()
            self.logger.log(log_file, "Error while creating table " +str(e))
            print("Error while creating table ")
            file.close()
            
    def insertIntoTableGoodData(self,Database):
        conn = self.dataBaseConnection(Database)
        #print(conn)
        goodFilePath= self.goodFilePath
        #print(goodFilePath)
        badFilePath = self.badFilePath
        #print(badFilePath)
        onlyfiles = [f for f in os.listdir(goodFilePath)]
        #print(onlyfiles)
        log_file = open("Training_Logs/DbInsertLog.txt", 'a+')
        count=0
        for file in onlyfiles:
            print(file+"\t"+str(count))
            count+=1
            try: 
                f=open(goodFilePath+'/'+file, "r")
                next(f)
                reader = csv.reader(f, delimiter="\n")
                for line in enumerate(reader):
                    for list_ in (line[1]):
                        try:
                            conn.execute('INSERT INTO Good_Raw_Data values ({values})'.format(values=(list_)))
                            self.logger.log(log_file," %s: File loaded successfully!!" % file)
                            conn.commit()
                        except Exception as e:
                            print(e)
            
            except Exception as e:
                conn.rollback()
                print("Error while creating table")
                self.logger.log(log_file,"Error while creating table: %s " % e)
                shutil.move(goodFilePath+'/' + file, badFilePath)
                self.logger.log(log_file, "File Moved Successfully %s" % file)
    def selectingDatafromtableintocsv(self,Database):
        self.fileFromDb = 'Training_FileFromDB/'
        self.fileName = 'InputFile.csv'
        log_file = open("Training_Logs/ExportToCsv.txt", 'a+')
        try:
            conn = self.dataBaseConnection(Database)
            sqlSelect = "SELECT *  FROM Good_Raw_Data"
            cursor = conn.cursor()

            cursor.execute(sqlSelect)

            results = cursor.fetchall()
            # Get the headers of the csv file
            headers = [i[0] for i in cursor.description]

            #Make the CSV ouput directory
            if not os.path.isdir(self.fileFromDb):
                os.makedirs(self.fileFromDb)

            # Open CSV file for writing.
            csvFile = csv.writer(open(self.fileFromDb + self.fileName, 'w', newline=''),delimiter=',', lineterminator='\r\n',quoting=csv.QUOTE_ALL, escapechar='\\')

            # Add the headers and data to the CSV file.
            csvFile.writerow(headers)
            csvFile.writerows(results)

            self.logger.log(log_file, "File exported successfully!!!")
            log_file.close()

        except Exception as e:
            self.logger.log(log_file, "File exporting failed. Error : %s" %e)
            log_file.close()



            
