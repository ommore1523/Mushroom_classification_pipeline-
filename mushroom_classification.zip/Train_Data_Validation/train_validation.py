import shutil 
import os
from datetime import datetime
import re
import pandas as pd
from Py_Log_File.logger import App_logger

#path=input("Enter a Path of directory :\t")

import json

class Raw_Data_validation:
    
    def __init__(self,path):
        self.path=path
        self.schema="schema_training.json"
        self.logger=App_logger()
        
    def valuesFromSchema(self):
        try:
            f=open(self.schema,"r")
            dic = json.load(f)
            f.close()
            pattern = dic['SampleFileName']
            LengthOfDateStampInFile = dic['LengthOfDateStampInFile']
            LengthOfTimeStampInFile = dic['LengthOfTimeStampInFile']
            column_names = dic['ColName']
            NumberofColumns = dic['NumberofColumns']
            log_file=open("Training_Logs/valuesfromSchemaValidationLog.txt","a+")
            self.logger.log(log_file,"Schema file reading successfully done")
            log_file.close()
        except Exception as e:
            #print("Error occure at schema reading")
            log_file=open("Training_Logs/valuesfromSchemaValidationLog.txt","a+")
            self.logger.log(log_file,"Schema file reading Error Occured")
            log_file.close()
        return pattern ,LengthOfDateStampInFile ,LengthOfTimeStampInFile, column_names ,NumberofColumns 
    
    def manualRegexCreation(self):
        print("Manual regex")
        regex = "['mushroom']+['\_'']+[\d_]+[\d]+\.csv"  # mushroom_08012020_120000.csv
        return regex
    
    def createDirectoryForGoodBadRawData(self):
        try:
            path = os.path.join("Training_Raw_files_validated/", "Good_Raw/")
            if not os.path.isdir(path):
                os.makedirs(path)
            path=os.path.join("Training_Raw_files_validated/","Bad_Raw/")
            if not os.path.isdir(path):
                os.makedirs(path)
            log_file=open("Training_Logs/CreateGoodBad_dir_log.txt","a+")
            #print("Successfully Created GOOD_BAD data folder")
            self.logger.log(log_file,"Successfully Created GOOD_BAD data folder")
            log_file.close()        
        except:
            #print("Error occured While creating file")
            log_file=open("Training_Logs/CreateGoodBad_dir_log.txt","a+")
            #print("Error while Creating GOOD_BAD data folder")
            self.logger.log(log_file,"Error while Creating GOOD_BAD data folder")
            log_file.close()
            
    def deleteExistingGoodDataTrainingFolder(self):
        try:
            path="Training_Raw_files_validated/Good_Raw/"
            shutil.rmtree(path)
            log_file=open("Training_Logs/DeleteGood_BAD_dir_log.txt","a+")
            #print(" Deleteing GOOD data folder successfully done")
            self.logger.log(log_file,"Deleteing GOOD data folder successfully don")
            log_file.close()
        except:
            log_file=open("Training_Logs/DeleteGood_BAD_dir_log.txt","a+")
            #print("Error while Deleteing GOOD data folder")
            self.logger.log(log_file,"Error while Deleteing GOOD data folder")
            log_file.close()
            
    def deleteExistingBadDataTrainingFolder(self):
        try:
            path="Training_Raw_files_validated/Bad_Raw/"
            shutil.rmtree(path)
            log_file=open("Training_Logs/DeleteGood_BAD_dir_log.txt","a+")
            #print(" Deleteing BAD data folder successfully done")
            self.logger.log(log_file,"Deleteing BAD data folder successfully don")
            log_file.close()
        except:
            log_file=open("Training_Logs/DeleteGood_BAD_dir_log.txt","a+")
            #print("Error while Deleteing BAD data folder")
            self.logger.log(log_file,"Error while Deleteing BAD data folder") 
            log_file.close()
            
    def moveBadFilesToArchiveBad(self):
        try:
            source="Training_Raw_files_validated/Bad_Raw/"
            dest="TrainingArchiveBadData/"
            if not os.path.isdir(dest):
                os.makedirs(dest)
            for file in os.listdir(source):
                shutil.move(source+file, dest)
            log_file=open("Training_Logs/DeleteGood_BAD_dir_log.txt","a+")
            #print("Moving to Archived Data successfull ")
            self.logger.log(log_file,"Moving to Archived Data successfull") 
            log_file.close()   
        except:
            log_file=open("Training_Logs/DeleteGood_BAD_dir_log.txt","a+")
            #print(" Moving data to archive successfully done")
            self.logger.log(log_file,"Moving data to archive successfully done")
            log_file.close()
            
    def validationFileNameRaw(self,regex,LengthOfDateStampInFile,LengthOfTimeStampInFile):
        self.deleteExistingGoodDataTrainingFolder()
        self.deleteExistingBadDataTrainingFolder()
        log_file = open("Training_Logs/nameValidationLog.txt", 'a+')
        try:
            self.createDirectoryForGoodBadRawData()
            for filename in os.listdir(self.path):
                #print(filename)
                if re.match(regex,filename):
                    splitDot=re.split(".csv",filename)
                    splitDot=re.split("_",splitDot[0])
                    if len(splitDot[1]) == LengthOfDateStampInFile :
                        if len(splitDot[2]) == LengthOfTimeStampInFile :
                            shutil.copyfile("Training_Batch_Files/"+filename, "Training_Raw_files_validated/Good_Raw/"+filename) 
                            self.logger.log(log_file,"Valid File name!! File moved to GoodRaw Folder ")
                        else:
                            shutil.copyfile("Training_Batch_Files/" + filename, "Training_Raw_files_validated/Bad_Raw/"+filename)
                            self.logger.log(log_file,"Invalid File name!! File moved to GoodRaw Folder ")
                    else:
                        shutil.copyfile("Training_Batch_Files/" + filename, "Training_Raw_files_validated/Bad_Raw/"+filename)
                        self.logger.log(log_file,"Invalid File name!! File moved to GoodRaw Folder ")
                else:
                    shutil.copyfile("Training_Batch_Files/" + filename, "Training_Raw_files_validated/Bad_Raw/"+filename)
                    self.logger.log(log_file,"Invalid File name!! File moved to GoodRaw Folder ")
            log_file.close()                
        except:
            #print("Error in Validaation of filename")
            self.logger.log(log_file,"Error in Validaation of filename")
            log_file.close()
            
    def validateColumnLength(self,NumberofColumns):
        log_file = open("Training_Logs/columnValidationLog.txt", 'a+')
        try:
            for file in os.listdir("Training_Raw_files_validated/Good_Raw/"):
                csv=pd.read_csv("Training_Raw_files_validated/Good_Raw/"+file)
                if csv.shape[1]==NumberofColumns:
                    pass
                else:
                    shutil.move("Training_Raw_files_validated/Good_Raw/"+file,"Training_Raw_files_validated/Bad_Raw")
                #print("Number of columns validation done successfully.")
                self.logger.log(log_file,"Number of columns validation done successfully.") 
            log_file.close()   
        except:
            self.logger.log(log_file,"Error in Number of column validation.")
            print("Error in Number of column validation.")
            log_file.close()
            
    def validateMissingValuesInWholeColumn(self):
        log_file = open("Training_Logs/validateMissingValuesInWholeColumn.txt", 'a+')
        try:
            #iterate over each file
            for file in os.listdir("Training_Raw_files_validated/Good_Raw/"):
                #iterate over each file column
                csv=pd.read_csv("Training_Raw_files_validated/Good_Raw/"+file)
                for columns in csv:
                    if ( len(csv[columns]) - csv[columns].count() == len(csv[columns]) ) :
                        shutil.move("Training_Raw_files_validated/Good_Raw/"+file,"Training_Raw_files_validated/Bad_Raw")
                        
                        self.logger.log(log_file,"validateMissingValuesInWholeColumn moved file to bad_raw folder")
                    else:
                        pass
            #print("validateMissingValuesInWholeColumn Done successfully")        
            self.logger.log(log_file,"validateMissingValuesInWholeColumn Done successfully")        
            log_file.close()            
        except:
            #print("Error while validateMissingValuesInWholeColumn ")
            self.logger.log(log_file,"validateMissingValuesInWholeColumn occured Error")        
            log_file.close() 