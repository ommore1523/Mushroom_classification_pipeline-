import pandas as pd 
import os
from Py_Log_File.logger import App_logger

class DataTranform:
    def __init__(self):
        self.goodDataPath="Prediction_Raw_files_validated/Good_Raw/"
        self.logger=App_logger()
        
    def addQuotesToStringValuesInColumn(self):
        log_file = open("Prediction_Logs/DataTranform_log.txt", 'a+')
        onlyfiles = [f for f in os.listdir("Prediction_Raw_files_validated/Good_Raw/")]
        try:
            for file in onlyfiles:
                data=pd.read_csv("Prediction_Raw_files_validated/Good_Raw/"+file)
                for column in data.columns:
                    count = data[column][data[column] == '?'].count()
                    if count != 0:
                        #data[column] = data[column].replace('?', "'?'")
                        data[column] = data[column].apply(lambda x: "'?'" if x == '?' else x)
                        data.to_csv("Prediction_Raw_files_validated/Good_Raw/"+file,index=False)
            print("Data tranformation addQuotesToStringValuesInColumn successful")    
            self.logger.log(log_file,"Data tranformation addQuotesToStringValuesInColumn successful")
            log_file.close()        
        
        except:
            print("Error Occured at  addQuotesToStringValuesInColumn ")
            self.logger.log(log_file,"Data tranformation addQuotesToStringValuesInColumn Error occured")
            log_file.close()    
            
        
#obj= DataTranform()
#obj.addQuotesToStringValuesInColumn()
