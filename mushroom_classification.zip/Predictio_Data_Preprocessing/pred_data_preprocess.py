import numpy as np
import os
import pandas as pd
from Py_Log_File.logger import App_logger
#from autoimpute.imputations import SingleImputer

class Preprocessor:
    
    def __init__(self):
        self.logger=App_logger()
    
    def dropUnnecessaryColumns(self,data,columnNameList):
        log_file=open("Prediction_Logs/ModelPredictionLog.txt", 'a+')
        data = data.drop(columnNameList,axis=1)
        self.logger.log(log_file, 'Drop unnecessary columns compledted')
        return data
    
    def replaceInvalidValuesWithNull(self,data):
        log_file=open("Prediction_Logs/ModelPredictionLog.txt", 'a+')
        for column in data.columns:
            count = data[column][data[column] == '?'].count()
            if count != 0:
                data[column] = data[column].replace('?', np.nan)
        self.logger.log(log_file, 'Replacing "?" with nan complted')        
        return data
    
    def encodeCategoricalValues(self,data):
        log_file=open("Prediction_Logs/ModelPredictionLog.txt", 'a+')
        #data["class"] = data["class"].map({'p': 1, 'e': 2})
        for column in data.columns:
            print(column)
            data= pd.get_dummies(data, columns=[column])
        self.logger.log(log_file, 'Encoding categorial data completed')    
        return data
    
    def separate_label_feature(self, data, label_column_name):
        log_file=open("Prediction_Logs/ModelPredictionLog.txt", 'a+')
        self.logger.log(log_file, 'Entered the separate_label_feature method of the Preprocessor class')
        try:
            self.X=data.drop(labels=label_column_name,axis=1) # drop the columns specified and separate the feature columns
            self.Y=data[label_column_name] # Filter the Label columns
            self.logger.log(log_file,'Label Separation Successful. Exited the separate_label_feature method of the Preprocessor class')
            return self.X,self.Y
        except Exception as e:
            self.logger.log(log_file,'Exception occured in separate_label_feature method of the Preprocessor class. Exception message:  ' + str(e))
            self.logger.log(log_file, 'Label Separation Unsuccessful. Exited the separate_label_feature method of the Preprocessor class')
            raise Exception()
    
    def is_null_present(self,data):
        log_file=open("Prediction_Logs/ModelPredictionLog.txt", 'a+')
        self.logger.log(log_file, 'Entered the is_null_present method of the Preprocessor class')
        self.null_present = False
        self.cols_with_missing_values=[]
        self.cols = data.columns
        try:
            null=data.isna().sum()
            for i in range(len(null)):
                if null[i]>0:
                    self.null_present = True
                    self.cols_with_missing_values.append(self.cols[i])
            if self.null_present == True:
                df=pd.DataFrame({'columns':data.columns ,"Missing":np.asarray(data.isna().sum())})
                path="Pred_preprocessing_data/"
                if not os.path.isdir(path):
                    os.makedirs(path)
                df.to_csv('Pred_preprocessing_data/null_values.csv')
                self.logger.log(log_file, 'Successfully checked for null values')
            return self.null_present , self.cols_with_missing_values   
        except:
            self.logger.log(log_file, 'Error while check for null values')
    
    def impute_missing_values(self,data, cols_with_missing_values):
        log_file=open("Prediction_Logs/ModelPredictionLog.txt", 'a+')
        self.data=data
        self.cols_with_missing_values=cols_with_missing_values
        try:
            for column in (self.cols_with_missing_values):
                self.data[column].fillna(self.data[column].mode()[0], inplace=True)
            self.logger.log(log_file, 'Missing values imputer done...')
            return self.data
        except:
            self.logger.log(log_file, 'Error Missing values imputer done')    
        
    def remove_columns(self,data,columns):
        log_file=open("Prediction_Logs/ModelPredictionLog.txt", 'a+')
        self.loggger.log(log_file,"Entered to Remove  Columns ...")
        self.data=data
        self.columns=columns
        try:
            self.data=self.data.drop(labels=self.columns,axis=1)
            self.loggger.log(log_file,"Columns Removed Done successfully..")
            return self.useful_data
        except Exception as e:
            self.logger.log(log_file,"Error occeured While reomving columns"+str(e))
            raise Exception()
            
    
#obj1=Preprocessor()
#data=obj1.dropUnnecessaryColumns(data,['veiltype'])
#print(data.shape)
#obj1.replaceInvalidValuesWithNull(data)
#is_null_present,cols_with_missing_values=obj1.is_null_present(data)
#is_null_present,cols_with_missing_values