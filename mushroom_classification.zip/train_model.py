from Py_Log_File.logger import App_logger
from Train_read_data.train_read_data import Data_Getter
from Train_Data_Preprocessing.train_data_preprocessing import Preprocessor 
from Train_File_Operation.train_file_operation import File_Operation
from Apply_Clustering.train_clustering import KMeansClustering
from Train_Model_Finder.model_finder import Model_Finder
from sklearn.model_selection import train_test_split


class Train_model:
    def __init__(self ):
        self.logger= App_logger()
        self.Data_Getter=Data_Getter()
        self.Preprocessor=Preprocessor()
        self.File_Operation=File_Operation()
        self.KMeansClustering=KMeansClustering()
        self.Model_Finder=Model_Finder()

    def train_model(self):
        log_file = open("Training_Logs/General_Log.txt", 'a+')
        self.logger.log(log_file,"Started Data Validation Process...") 
        try:
            data=self.Data_Getter.get_data()
            self.logger.log(log_file,"Successfully loaded data ...") 
            self.Preprocessor.dropUnnecessaryColumns(data,['veiltype'])
            self.logger.log(log_file,"Successfully Dropped column which is not userful...") 
            self.Preprocessor.replaceInvalidValuesWithNull(data)
            self.logger.log(log_file,"Successfully replaced invalid values with null...") 
            is_null_present,cols_with_missing_values=self.Preprocessor.is_null_present(data)
            self.logger.log(log_file,"Successfully checked whether the null values are present or not") 

            if (is_null_present):
                self.Preprocessor.impute_missing_values(data, cols_with_missing_values)
                self.logger.log(log_file,"Successfully imputed the missing values..") 

            data=self.Preprocessor.encodeCategoricalValues(data)
            self.logger.log(log_file,"Successfully Encoded categorial data...")
            X,Y=self.Preprocessor.separate_label_feature(data, "class")
            self.logger.log(log_file,"Successfully Separated class columns ...")
            num_of_clusters=self.KMeansClustering.elbow_plot(X)
            self.logger.log(log_file,"Successfully Got no of cluster i.e "+str(num_of_clusters)) 
            X=self.KMeansClustering.create_clusters(X,num_of_clusters)
            self.logger.log(log_file,"Successfully created clusters and added to new column") 
            #X=X[0]
            X["Labels"]=Y
            #print(X.shape)
            print(X)
            self.logger.log(log_file,"Successfully got Final dataset") 
            list_of_clusters=X['Cluster'].unique()
            print(list_of_clusters)
            self.logger.log(log_file,"Unique nuumber of clusters found out "+str(list_of_clusters)) 
            self.logger.log(log_file,"")
            self.logger.log(log_file,"Started Cluster wise Model finding :")  
            for i  in list_of_clusters:
                cluster_data=X[X['Cluster']==i] 
                cluster_features=cluster_data.drop(['Cluster','Labels'],axis=1)
                cluster_label= cluster_data['Labels']
                train_x, test_x,train_y, test_y = train_test_split(cluster_features, cluster_label, test_size=1 / 3, random_state=36)
                best_model_name,best_model=self.Model_Finder.get_best_model(train_x,train_y,test_x,test_y)
                print(best_model_name,best_model)
                save_model=self.File_Operation.save_model(best_model,best_model_name+str(i))
                self.logger.log(log_file,"Model saved"+str(i))

        except Exception as e:
            self.logger.log(log_file,"Errot while training.." +str(e)) 
            







            


         
