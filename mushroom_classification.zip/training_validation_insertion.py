
from Py_Log_File.logger import App_logger
from Train_Data_Validation.train_validation import Raw_Data_validation
from Train_Data_Transform.traintransform import DataTranform
from TrainDbOperation.traindb import dBOperation
from Train_read_data.train_read_data import Data_Getter


#path="Training_Batch_Files/"

class train_validation_class:
    def __init__(self,path):
        self.logger=App_logger()
        self.Raw_Data_validation=Raw_Data_validation(path)
        self.DataTranform=DataTranform()
        self.dBOperation=dBOperation()
        self.Data_Getter=Data_Getter()

    def train_validation(self):
        try:
            log_file = open("Training_Logs/General_Log.txt", 'a+')
            self.logger.log(log_file,"Started Data Validation Process...") 
            pattern ,LengthOfDateStampInFile ,LengthOfTimeStampInFile, column_names ,NumberofColumns =self.Raw_Data_validation.valuesFromSchema()
            self.logger.log(log_file,"Successfully read schema file") 
            regex=self.Raw_Data_validation.manualRegexCreation()
            self.logger.log(log_file,"Successfully Read regex pattern") 
            self.Raw_Data_validation.validationFileNameRaw(regex,LengthOfDateStampInFile ,LengthOfTimeStampInFile ) 
            self.logger.log(log_file,"Successfully done Filenamevalidation") 
            self.Raw_Data_validation.validateColumnLength(NumberofColumns)
            self.logger.log(log_file,"Successfully done column length validation") 
            self.Raw_Data_validation.validateMissingValuesInWholeColumn()
            self.logger.log(log_file,"Successfully done Validation of missing values in whole columns") 
            self.logger.log(log_file,"End of Data Validation step")
            self.logger.log(log_file,"")     
            self.logger.log(log_file,"Data transformation Process starts...")
            self.DataTranform.addQuotesToStringValuesInColumn()
            self.logger.log(log_file,"Successfully done adding Quotes to string values.. ")
            self.logger.log(log_file,"End of dataTranformation ")
            self.logger.log(log_file,"")
            self.logger.log(log_file,"Started DataBase Operation... ")
            self.dBOperation.dataBaseConnection("training")
            self.logger.log(log_file,"Successfully Connected to Database")
            self.dBOperation.createTableDb("training",column_names)
            self.logger.log(log_file,"Successfully created database ")
            self.dBOperation.insertIntoTableGoodData("training")
            self.logger.log(log_file,"Successfully inserted good data to database")
            self.dBOperation.selectingDatafromtableintocsv("training")
            self.logger.log(log_file,"Successfully saved main csv file to local system... ")
            self.logger.log(log_file,"End of database operation.. ")
            self.logger.log(log_file,"Completed Data Validation Operation ")
        except Exception as e:
            log_file = open("Training_Logs/General_Log.txt", 'a+')
            self.logger.log(log_file,"Error Occurred in Data set validation: "+str(e))            
    
    
                    