from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics  import roc_auc_score,accuracy_score
from sklearn.neighbors import KNeighborsClassifier
import pandas as pd
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from Py_Log_File.logger import App_logger

class Model_Finder:
    def __init__(self):
        self.logger=App_logger()
        self.clf = RandomForestClassifier()
        self.knn=KNeighborsClassifier()
    
    def get_best_params_for_random_forest(self,train_x,train_y):
        log_file=open("Training_Logs/ModelTrainingLog.txt", 'a+')
        self.logger.log(log_file, 'Entered the get_best_params_for_random_forest method of the Model_Finder class')
        try:
            # initializing with different combination of parameters
            self.param_grid = {"n_estimators": [10, 50, 100, 130], "criterion": ['gini', 'entropy'],
                               "max_depth": range(2, 4, 1), "max_features": ['auto', 'log2']}

            #Creating an object of the Grid Search class
            self.grid = GridSearchCV(estimator=self.clf, param_grid=self.param_grid, cv=5,  verbose=3)
            #finding the best parameters
            self.grid.fit(train_x, train_y)

            #extracting the best parameters
            self.criterion = self.grid.best_params_['criterion']
            self.max_depth = self.grid.best_params_['max_depth']
            self.max_features = self.grid.best_params_['max_features']
            self.n_estimators = self.grid.best_params_['n_estimators']

            #creating a new model with the best parameters
            self.clf = RandomForestClassifier(n_estimators=self.n_estimators, criterion=self.criterion,
                                              max_depth=self.max_depth, max_features=self.max_features)
            # training the mew model
            self.clf.fit(train_x, train_y)
            self.logger.log(log_file,'Random Forest best params: '+str(self.grid.best_params_)+'. Exited the get_best_params_for_random_forest method of the Model_Finder class')
            return self.clf
        except Exception as e:
            self.logger.log(log_file,'Exception occured in get_best_params_for_random_forest method of the Model_Finder class. Exception message:  ' + str( e))
            raise Exception()
            
    def get_best_params_for_KNN(self, train_x, train_y):
        log_file=open("Training_Logs/ModelTrainingLog.txt", 'a+')
        self.logger.log(log_file,"Entered to Best params for KNN")

        try:
            self.param_grid_knn = {
                'algorithm' : ['ball_tree', 'kd_tree', 'brute'],
                'leaf_size' : [10,17,24,28,30,35],
                'n_neighbors':[4,5,8,10,11],
                'p':[1,2]
                }

            # Creating an object of the Grid Search class
            self.grid = GridSearchCV(self.knn, self.param_grid_knn, verbose=3, cv=5)
            # finding the best parameters
            self.grid.fit(train_x, train_y)
            
            # extracting the best parameters
            self.algorithm = self.grid.best_params_['algorithm']
            self.leaf_size = self.grid.best_params_['leaf_size']
            self.n_neighbors = self.grid.best_params_['n_neighbors']
            self.p  = self.grid.best_params_['p']

            # creating a new model with the best parameters
            self.knn = KNeighborsClassifier(algorithm=self.algorithm, leaf_size=self.leaf_size, n_neighbors=self.n_neighbors,p=self.p,n_jobs=-1)
            # training the mew model
            self.knn.fit(train_x, train_y)
            self.logger.log(log_file,'KNN best params: ' + str(self.grid.best_params_) + '. Exited the KNN method of the Model_Finder class')
            print("Knn best parameter get completed ",)
            return self.knn
        except Exception as e:
            self.logger.log(log_file, 'Exception occured in knn method of the Model_Finder class. Exception message:' + str(e))
            raise Exception()
            
    def get_best_model(self,train_x,train_y,test_x,test_y):
        log_file=open("Training_Logs/ModelTrainingLog.txt", 'a+')
        self.logger.log(log_file,"Entered to Get best model Process ")
        try:
            self.knn= self.get_best_params_for_KNN(train_x,train_y)
            self.prediction_knn = self.knn.predict(test_x)
            if len(test_y.unique()) == 1: #if there is only one label in y, then roc_auc_score returns error. We will use accuracy in that case
                self.knn_score = accuracy_score(test_y, self.prediction_knn)
                print("Knn Unique",self.knn_score)
                self.logger.log(log_file, 'Accuracy for knn:' + str(self.knn_score)) 
            else:
                self.knn_score = roc_auc_score(test_y, self.prediction_knn) # AUC for KNN
                print("KNN AUC score",self.knn_score)
                self.knn_confusion=confusion_matrix(test_y, self.prediction_knn)
                print("KNN confusion matrix", self.knn_confusion)
                self.logger.log(log_file, 'AUC for knn:' + str(self.knn_score)) # Log AUC 
                self.logger.log(log_file,'Confusion matrix for knn' + str(self.knn_confusion))
                
            # create best model for Random Forest
            self.random_forest=self.get_best_params_for_random_forest(train_x,train_y)
            self.prediction_random_forest=self.random_forest.predict(test_x) # prediction using the Random Forest Algorithm

            if len(test_y.unique()) == 1:#if there is only one label in y, then roc_auc_score returns error. We will use accuracy in that case
                self.random_forest_score = accuracy_score((test_y),self.prediction_random_forest)
                print("Unique random forest", self.random_forest_score )
                self.logger.log(log_file, 'Accuracy for RF:' + str(self.random_forest_score))
            else:
                self.Random_confusion=confusion_matrix(test_y, self.prediction_random_forest)
                print("Random forest confusion",self.Random_confusion)
                self.random_forest_score = roc_auc_score(test_y, self.prediction_random_forest) # AUC for Random Forest
                print("Random forest AUC", self.random_forest_score )
                self.logger.log(log_file, 'AUC for RF:' + str(self.random_forest_score)) 
                self.logger.log(log_file, 'Confusion matrix for Random forest' + str(self.Random_confusion)) 
                
            print("random_forest_score ",self.random_forest_score ) 
            print(" knn_score", self.knn_score)
            #comparing the two models
            if(self.random_forest_score <  self.knn_score):
                return 'KNN',self.knn
            else:
                return 'RandomForest',self.random_forest    
                
        except Exception as e:
            self.logger.log(log_file,'Exception occured in get_best_model method of the Model_Finder class. Exception message: ' + str(e))
        
            