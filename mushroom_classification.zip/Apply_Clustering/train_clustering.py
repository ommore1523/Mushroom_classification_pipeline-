import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from kneed import KneeLocator
from Py_Log_File.logger import App_logger
from Train_File_Operation.train_file_operation import File_Operation

class KMeansClustering:
    def __init__(self):
        self.logger=App_logger()
        self.File_Operation=File_Operation()
    def elbow_plot(self,data):
        log_file=open("Training_Logs/ModelTrainingLog.txt", 'a+')
        self.logger.log(log_file,"Entered to Elbow_plot process")
        wcss=[]
        try:
            for i in range(1,11):
                kmeans=KMeans(n_clusters=i,init='k-means++',random_state=42) 
                kmeans.fit(data)
                wcss.append(kmeans.inertia_)
            print(wcss)    
            plt.plot(range(1,11),wcss)
            plt.title('The Elbow Method')
            plt.xlabel('Number of clusters')
            plt.ylabel('WCSS')
            plt.savefig('preprocessing_data/K-Means_Elbow.PNG')
            self.kn = KneeLocator(range(1, 11), wcss, curve='convex', direction='decreasing')
            self.logger.log(log_file,"Elobow plot successfully created ")
            log_file.close()
            return self.kn.knee
        except Exception as e:
            self.logger.log(log_file,"Erro in Elobow plot ")
            raise Exception()
    def create_clusters(self,data,number_of_clusters):
        self.data=data
        log_file=open("Training_Logs/ModelTrainingLog.txt", 'a+')
        self.logger.log(log_file,"Entered to Create Clusters process ...")
        try:
            self.kmeans = KMeans(n_clusters=number_of_clusters, init='k-means++', random_state=42)
            self.y_kmeans=self.kmeans.fit_predict(self.data)
            #print(type(self.y_kmeans))
            self.save_model = self.File_Operation.save_model(self.kmeans, 'KMeans')
            self.data['Cluster']=list(self.y_kmeans)
            self.logger.log(log_file, 'succesfully created '+str(self.kn.knee)+ 'clusters. Exited the create_clusters method of the KMeansClustering class')
            #print(self.data.shape)
            #print(type(self.data))
            #print(self.data)
            return self.data 
        except Exception as e:
            #raise Exception()
            print("Error")
            self.logger.log(log_file,"Error in create cluster" +str(e))
               
#obj2=KMeansClustering ()           
#num_of_clusters=obj2.elbow_plot(X)             
#X=obj2.create_clusters(X,num_of_clusters)